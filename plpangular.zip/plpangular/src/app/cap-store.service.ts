import { Injectable } from '@angular/core';
import {HttpClient} from '@angular/common/http'
// import { Observable } from 'rxjs';
import { CapStore } from './cap-store';
import { Observable } from 'rxjs';
@Injectable({
  providedIn: 'root'
})
export class CapStoreService {
  ordStatus: any;
  ordId: any;
  constructor(private httpClient:HttpClient) { }

  baseUrl = "http://localhost:8086";
  getOrdStatus(){
    return this.ordStatus;
   }
   
  setOrdStatus(ordStatus:string){
    this.ordStatus=ordStatus;
   }
   getOrdStatus2(){
    return this.ordStatus;
   }
   
  setOrdStatus2(ordId:string){
    this.ordId=ordId;
   }
   getOrdId(){
    return this.ordId;
   }
   
  setOrdId(ordId:string){
    this.ordId=ordId;
   }

  showAllProducts():Observable<CapStore[]>
  {
    console.log("gh");
    return this.httpClient.get<CapStore[]>("http://localhost:8086/capstore");
  }
  showPlacedProducts():Observable<CapStore[]>
  {
    return this.httpClient.get<CapStore[]>("http://localhost:8086/placedproducts/"+'pld');
  }
  showDispatchedProducts():Observable<CapStore[]>
  {
    return this.httpClient.get<CapStore[]>("http://localhost:8086/dispatchedproducts/"+'disp');
  }
  updatePld(productOrdId: string,productOrdStatus: string):Observable<CapStore[]>{
    return this.httpClient.get<CapStore[]>("http://localhost:8086/updatePlacedProducts/"+ productOrdId + '/' + productOrdStatus);
  }
  
  updateDisp(productOrdId: string,productOrdStatus: string):Observable<CapStore[]>{
    return this.httpClient.get<CapStore[]>("http://localhost:8086/updateDispatchedProducts/"+ productOrdId + '/' + productOrdStatus);
  }
  updateProduct(productOrdId: string,productOrdStatus: string):Observable<CapStore[]>{
  
    let url = this.baseUrl + "/updateProduct/"+ productOrdId + '/' + productOrdStatus
    console.log(url)
    return this.httpClient.get<CapStore[]>(url);
  }
}
