import { TestBed } from '@angular/core/testing';

import { CapStoreService } from './cap-store.service';

describe('CapStoreService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: CapStoreService = TestBed.get(CapStoreService);
    expect(service).toBeTruthy();
  });
});
