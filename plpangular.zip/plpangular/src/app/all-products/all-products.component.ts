import { Component, OnInit } from '@angular/core';
import { CapStoreService } from '../cap-store.service';
import { CapStore } from '../cap-store';

@Component({
  selector: 'app-all-products',
  templateUrl: './all-products.component.html',
  styleUrls: ['./all-products.component.css']
})
export class AllProductsComponent implements OnInit {
  capstore: CapStore[];

  constructor(private capStoreService:CapStoreService) { }

  ngOnInit() {
    this.capStoreService.showAllProducts().subscribe(response=>this.handleSuccessfulResponse(response));

  }
 
    handleSuccessfulResponse(response){
      this.capstore=response;
      console.log(this.capstore);
      
     //console.log(this.capstore[0].ordStatus);
      //  for(let i=0;i<this.capstore.length;i++){
      //     if(this.capstore[i].ordStatus==='pld'){
      //     this.capStoreService.setOrdId(this.capstore[i].ordId);
      //     this.capStoreService.setOrdStatus(this.capstore[i].ordStatus);
      //     }
      //     else if(this.capstore[i].ordStatus==='disp'){
      //       this.capStoreService.setOrdId(this.capstore[i].ordId);
      //       this.capStoreService.setOrdStatus(this.capstore[i].ordStatus);
      //     }
      //     else{
      //     this.capStoreService.setOrdId(this.capstore[i].ordId);
      //     this.capStoreService.setOrdStatus(this.capstore[i].ordStatus);
      //     }
      //   }
  
    }
updateProduct(productOrdId: string,productOrdStatus: string){
  this.capStoreService.updateProduct(productOrdId,productOrdStatus).subscribe(data => {
    this.capstore = data;
    //console.log(this.capstore)
});
}
}
