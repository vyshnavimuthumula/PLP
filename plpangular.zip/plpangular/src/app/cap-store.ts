export class CapStore {
     ordId: string;
     custId: string;
     merId: string;
     ordPrice: string;
     ordQty: number;
     ordStatus: string;
     proId: string;

    // constructor(
    //      ordId: string,
    //      custId: string,
    //      merId: string,
    //      ordPrice: string,
    //      ordQty: number,
    //      ordStatus: string,
    //      proId: string
    // ) {
    // this.ordId = ordId;
    //      this.custId = custId;
    //      this.merId = merId;
    //      this.ordPrice = ordPrice;
    //      this.ordQty = ordQty;
    //      this.ordStatus = ordStatus;
    //      this.proId = proId;


    // // }
}