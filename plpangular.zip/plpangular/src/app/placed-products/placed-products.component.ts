import { Component, OnInit } from '@angular/core';
import { CapStoreService } from '../cap-store.service';
import { CapStore } from '../cap-store';

@Component({
  selector: 'app-placed-products',
  templateUrl: './placed-products.component.html',
  styleUrls: ['./placed-products.component.css']
})
export class PlacedProductsComponent implements OnInit {
  capstore: CapStore[];

  constructor(private capStoreService:CapStoreService) { }

  ngOnInit() {
    this.capStoreService.showPlacedProducts().subscribe(response=>this.handleSuccessfulResponse(response));
  }
  handleSuccessfulResponse(response){
    this.capstore=response;
    console.log(this.capstore);
     for(let i=0;i<this.capstore.length;i++){
       if(this.capstore[i].ordStatus==='pld'){
         this.capStoreService.setOrdId(this.capstore[i].ordId);
         console.log(this.capstore[i].ordId)
       }
  //}
    }
  }
updatePldStatus(productOrdId: string,productOrdStatus: string){
  this.capStoreService.updatePld(productOrdId,productOrdStatus).subscribe(data => {
    this.capstore = data;
    // console.log(this.capstore);
    // for(let i=0;i<this.capstore.length;i++){
    //     this.capStoreService.setordId(this.capstore[i].ordId);
    //     console.log(this.capstore[i].ordId);}
  });
}
}
