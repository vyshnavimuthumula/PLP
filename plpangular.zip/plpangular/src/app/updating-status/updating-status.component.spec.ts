import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { UpdatingStatusComponent } from './updating-status.component';

describe('UpdatingStatusComponent', () => {
  let component: UpdatingStatusComponent;
  let fixture: ComponentFixture<UpdatingStatusComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ UpdatingStatusComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(UpdatingStatusComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
