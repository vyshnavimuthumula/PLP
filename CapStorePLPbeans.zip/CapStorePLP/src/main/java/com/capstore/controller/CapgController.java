package com.capstore.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.capstore.bean.Customer;
import com.capstore.bean.WishItem;
import com.capstore.service.CapgService;

@RestController
public class CapgController {

	@Autowired CapgService capgService;
	
	@PostMapping("/register")
	public void registerCustomer(@RequestBody Customer customer) {
		capgService.registerCustomer(customer);
	}
	@PostMapping("/addWish/{custId}")
	public void addCustomerWish(@PathVariable String custId,@RequestBody WishItem wish) {
		capgService.addCustomerWish(custId,wish);
	}
}
